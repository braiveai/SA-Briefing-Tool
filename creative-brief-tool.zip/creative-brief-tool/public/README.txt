Add your sunny-logo.png file here.

Recommended size: 200px width, transparent background.
